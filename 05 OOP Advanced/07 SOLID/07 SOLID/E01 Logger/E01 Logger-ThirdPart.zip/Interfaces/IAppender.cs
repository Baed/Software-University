﻿namespace E01_Logger
{
    public interface IAppender
    {
        ILayout Layout { get; }

        void Append(string timeStamp, string reportLevel, string message);
    }
}