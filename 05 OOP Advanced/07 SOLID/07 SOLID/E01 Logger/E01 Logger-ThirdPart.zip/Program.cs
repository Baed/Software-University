﻿namespace E01_Logger
{
    using Appenders;
    using Entities;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
            ILayout xmlLayout = new XmlLayout();
            IAppender consoleAppender = new ConsoleAppender(xmlLayout);
            ILogger logger = new Logger(consoleAppender);

            logger.Fatal("3/31/2015 5:23:54 PM", "mscorlib.dll does not respond");
            logger.Critical("3/31/2015 5:23:54 PM", "No connection string found in App.config");
        }
    }
}
