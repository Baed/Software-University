﻿namespace E08_Military_Elite
{

    public interface IPrivate : ISoldier
    {
        double Salary { get; }
    }
}