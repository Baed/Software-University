﻿namespace E08_Military_Elite
{

    public interface ISpecialisedSoldier : IPrivate
    {
        string Corps { get; }
    }
}