﻿namespace E08_Military_Elite
{

    public interface IRepair
    {
        string Name { get; }

        int Hours { get; }
    }
}