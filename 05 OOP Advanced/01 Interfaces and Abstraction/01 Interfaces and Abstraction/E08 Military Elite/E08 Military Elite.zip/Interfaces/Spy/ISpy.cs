﻿namespace E08_Military_Elite
{

    public interface ISpy : ISoldier
    {
        int CodeNumber { get; }
    }
}