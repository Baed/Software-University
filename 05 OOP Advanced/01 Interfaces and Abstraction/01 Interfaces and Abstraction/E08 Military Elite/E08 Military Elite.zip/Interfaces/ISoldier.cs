﻿namespace E08_Military_Elite
{

    public interface ISoldier
    {
        string ID  { get; }

        string FirstName { get; }

        string LastName { get; }
    }
}