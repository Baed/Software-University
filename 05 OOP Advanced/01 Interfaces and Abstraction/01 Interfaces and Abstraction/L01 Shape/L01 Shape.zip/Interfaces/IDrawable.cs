﻿
public interface IDrawable
{
    void Draw();

    void DrawLine(int width, char end, char mid);
}

