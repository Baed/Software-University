﻿namespace E03___05_BarracksWars.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}