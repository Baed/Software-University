﻿namespace E03___05_BarracksWars.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}