﻿namespace E03___05_BarracksWars.Contracts
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}