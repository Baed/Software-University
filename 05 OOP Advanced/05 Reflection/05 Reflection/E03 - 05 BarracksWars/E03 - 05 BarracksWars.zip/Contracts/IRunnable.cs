﻿namespace E03___05_BarracksWars.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}