﻿namespace E05_MordorsCrueltyPlan.Models.Foods
{

    public class Junk : Food
    {
        private const int HappinessPoints = -1;

        public Junk() : base(HappinessPoints)
        {
        }
    }
}
