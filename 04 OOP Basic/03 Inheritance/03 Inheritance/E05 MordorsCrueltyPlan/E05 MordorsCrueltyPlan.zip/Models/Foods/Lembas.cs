﻿namespace E05_MordorsCrueltyPlan.Models.Foods
{

    public class Lembas : Food
    {
        private const int HappinessPoints = 3;

        public Lembas() : base(HappinessPoints)
        {
        }
    }
}
