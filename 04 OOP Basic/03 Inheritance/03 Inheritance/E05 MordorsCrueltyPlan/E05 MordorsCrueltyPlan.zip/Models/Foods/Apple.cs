﻿namespace E05_MordorsCrueltyPlan.Models.Foods
{

    public class Apple : Food
    {
        private const int HappinessPoints = 1;

        public Apple() : base(HappinessPoints)
        {

        }
    }
}
