﻿namespace E05_MordorsCrueltyPlan.Models.Foods
{

    public class Melon : Food
    {
        private const int HappinessPoints = 1;

        public Melon() : base(HappinessPoints)
        {
        }
    }
}
