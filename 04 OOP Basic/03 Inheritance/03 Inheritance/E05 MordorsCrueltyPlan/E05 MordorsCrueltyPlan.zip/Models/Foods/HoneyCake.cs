﻿namespace E05_MordorsCrueltyPlan.Models.Foods
{

    public class HoneyCake : Food
    {
        private const int HappinessPoints = 5;

        public HoneyCake() : base(HappinessPoints)
        {
        }
    }
}
