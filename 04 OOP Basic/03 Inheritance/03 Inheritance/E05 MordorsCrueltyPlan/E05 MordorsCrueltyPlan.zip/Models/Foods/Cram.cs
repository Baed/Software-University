﻿namespace E05_MordorsCrueltyPlan.Models.Foods
{

    public class Cram : Food
    {
        private const int HappinessPoints = 2;

        public Cram() : base(HappinessPoints)
        {
        }
    }
}
