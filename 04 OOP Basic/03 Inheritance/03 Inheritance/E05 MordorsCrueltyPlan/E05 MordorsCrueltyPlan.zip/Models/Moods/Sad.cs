﻿namespace E05_MordorsCrueltyPlan.Models.Moods
{

    public class Sad : Mood
    {
        private const string MoodName = "Sad";

        public Sad() : base(MoodName)
        {
        }
    }
}
