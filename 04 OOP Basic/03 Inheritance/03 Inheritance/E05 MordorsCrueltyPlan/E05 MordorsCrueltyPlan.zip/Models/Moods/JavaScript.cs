﻿namespace E05_MordorsCrueltyPlan.Models.Moods
{

    public class JavaScript : Mood
    {
        private const string MoodName = "JavaScript";

        public JavaScript() : base(MoodName)
        {
        }
    }
}
